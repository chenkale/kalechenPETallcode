#include "CoincidenceGrouper.hpp"
#include <math.h>

using namespace PETSYS;

CoincidenceGrouper::CoincidenceGrouper(SystemConfig *systemConfig, EventSink<Coincidence> *sink)
	: systemConfig(systemConfig), OverlappedEventHandler<GammaPhoton, Coincidence>(sink)
{
	nPrompts = 0;
}

CoincidenceGrouper::~CoincidenceGrouper()
{
}

void CoincidenceGrouper::report()
{
	printf(">> CoincidenceGrouper report\n");
	printf(" prompts passed\n");
	printf("  %10u \n", nPrompts);
	OverlappedEventHandler<GammaPhoton, Coincidence>::report();
}

EventBuffer<Coincidence> * CoincidenceGrouper::handleEvents(EventBuffer<GammaPhoton> *inBuffer)
{
	double cWindow = systemConfig->sw_trigger_coincidence_time_window;
	
	unsigned N =  inBuffer->getSize();
	EventBuffer<Coincidence> * outBuffer = new EventBuffer<Coincidence>(N, inBuffer);

	u_int32_t lPrompts = 0;
	for(unsigned i = 0; i < N; i++) {
		GammaPhoton &photon1 = inBuffer->get(i);
		for(unsigned j = i+1; j < N; j++) {
			GammaPhoton &photon2 = inBuffer->get(j);			
			if ((photon2.time - photon1.time) > (overlap + cWindow)) break;
			
			if(!systemConfig->isCoincidenceAllowed(photon1.region, photon2.region)) continue;
			
			if(fabs(photon1.time - photon2.time) <= cWindow) {

				for(unsigned k = j+1; k < N; k++) {
					GammaPhoton &photon3 = inBuffer->get(k);			
					if ((photon3.time - photon1.time) > (overlap + cWindow)) break;
					int chip1 = (photon1.region % 4096) / 128;
					int chip2 = (photon2.region % 4096) / 128;
					int chip3 = (photon3.region % 4096) / 128;
					//if (chip1 == chip2 || chip2 == chip3 || chip3 == chip1) break;
			
					if(!systemConfig->isCoincidenceAllowed(photon1.region, photon3.region)) continue;
			
					if(fabs(photon1.time - photon3.time) <= cWindow) {
						Coincidence &c = outBuffer->getWriteSlot();
						c.nPhotons = 3;
				
						bool first1 = photon1.region > photon2.region && photon1.region > photon3.region;
						bool first2 = photon2.region > photon1.region && photon2.region > photon3.region;
						bool middle1 = (photon1.region - photon2.region)*(photon1.region - photon3.region) < 0;
						bool middle2 = (photon2.region - photon1.region)*(photon2.region - photon3.region) < 0;
						bool last1 = photon2.region > photon1.region && photon2.region > photon3.region;
						bool last2 = photon2.region > photon1.region && photon2.region > photon3.region;

						c.photons[0] = first1 ? &photon1 : (first2 ? &photon2 : &photon3);
						c.photons[1] = middle1 ? &photon1 : (middle2 ? &photon2 : &photon3);
						c.photons[2] = last1 ? &photon1 : (last2 ? &photon2 : &photon3);
						//c.photons[0] = &photon1;
						//c.photons[1] = &photon2;
						//c.photons[2] = &photon3;
						c.valid = true;
						outBuffer->pushWriteSlot();
						lPrompts++;
					}
				}
			}
		}
	}
	atomicAdd(nPrompts, lPrompts);
	return outBuffer;
}
